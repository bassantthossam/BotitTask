import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create-product',
  templateUrl: './create-product.component.html',
  styleUrls: ['./create-product.component.css']
})
export class CreateProductComponent {
  
  _id:any;
  name!: string;
  price!: number;
  category!: string;
  edit: boolean =false;

  constructor(private http: HttpClient,private myRouter: Router,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const id = params['id'];
      //If id is undefined this means that the component is called to add new product 
    if(id==undefined){
      this.edit=false;
    }
    else{
      
      this.edit=true;
      this.name=params['name'];
      this.price=params['price'];
      this.category=params['category'];
      this._id=params['id'];
    }
  });
  }
//gets the user inputs and send a request to update the product using the products id
  editProduct(){
    const product = {
      name: this.name,
      price: this.price,
      category: this.category
    };
    if(this.price<0){
      alert('Number must be greater than or equal to 0.');
    }
    else{
    this.http.put('http://localhost:3000/productform/'+this._id, product)
      .subscribe(response => {
        console.log('Product added:', response);
        this.myRouter.navigate(['/Products']);
      }, error => {
        console.error('Failed to add product:', error);
      });
    }
  }
//create a new product based on the user input
  addProduct() {
    
    const product = {
      name: this.name,
      price: this.price,
      category: this.category
    };
if(this.price<0){
  alert('Number must be greater than or equal to 0.');
}
else{
    this.http.post('http://localhost:3000/productform', product)
      .subscribe(response => {
        console.log('Product added:', response);
        this.myRouter.navigate(['/Products']);

      }, error => {
        console.error('Failed to add product:', error);
      });
  }
}
goHome(){
  this.myRouter.navigate(['Products']);

}
}
