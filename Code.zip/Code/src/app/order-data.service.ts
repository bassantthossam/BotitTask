import { Injectable } from '@angular/core';
import{OrderInfo} from './orderInfo';
import { ProductInfo } from './productInfo';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class OrderDataService {

  _id!: any;
  name!: string;
  price!: number;
  category!: string;
  productList!: Observable<any[]>;

  constructor(private http: HttpClient,private myRouter: Router){}

  //routes to create product component and pass the product as a parameter
  editProduct(product:any){
    this._id=product._id;
    this.name=product.name;
    this.price=product.price;
    this.category=product.category;

    this.myRouter.navigate(['/createProduct'],{queryParams: { product}});

  }

  getProduct(id:number):any{
    this.productList.subscribe((products) => {
      const foundProduct = products.find((product) => product.id === id);
      return foundProduct;
  });
}
//gets the products info from the database
  getProductInfo(): Observable<any[]>{
    
    this.productList=this.http.get<any[]>('http://localhost:3000/products');
    return this.productList;
}


//sends a get request to get a filtered list using these parameters
  searchOrders(startDate: Date, endDate: Date, minPrice: number, maxPrice: number) {
    const params = {
      startDate:startDate.toString(),
      endDate:endDate.toString(),
      minPrice: minPrice.toString(),
      maxPrice: maxPrice.toString()
    };

    return this.http.get<any[]>('http://localhost:3000/orderSearch', { params });
  }

}
