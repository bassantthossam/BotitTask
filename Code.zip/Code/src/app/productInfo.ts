import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })
export class ProductInfo {
    name:String ;
    price: Number;
    category:String ;

    constructor(name:String,price: Number,category:String) { 
        this.name=name;
        this.price=price;
        this.category=category ; 

    }
}