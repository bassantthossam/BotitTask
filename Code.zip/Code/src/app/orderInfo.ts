import { ProductInfo } from './productInfo';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })
export class OrderInfo {
    id: Number;
    CustomerName:String ;
    TotalAmount: Number;
    Products:String;
    OrderDate:Date ;

    constructor(id: Number,CustomerName:String,TotalAmount: Number,Products:String,OrderDate:Date) { 
        this.CustomerName=CustomerName;
        this.id=id;
        this.TotalAmount=TotalAmount;
        this.Products=Products;
        this.OrderDate=OrderDate ;  
  }
}