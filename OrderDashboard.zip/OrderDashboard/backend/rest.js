const express = require('express');
var cors = require('cors');
const { MongoClient } = require('mongodb');
const mongoose = require('mongoose');
const uri = 'mongodb+srv://bassantthossam:BH1234@cluster0.gwvwumj.mongodb.net/?retryWrites=true&w=majority';
const DbShcema = require('./db');
const bodyParser = require('body-parser');
var onFinished = require('on-finished')


const app =express();

mongoose.connect(uri)    
.then(() => {
    console.log('Connected to MongoDB')
})
.catch(() => {
    console.log('Error connecting to MongoDB');
})

app.use(cors());

app.use(bodyParser.json());

//the requests related to the Order Component

//request to get the orders litst
app.get('/orders', (req, res) => {
      DbShcema[0].find().then((orders) => {
      res.json(orders);
  })
  .catch(() => {
      console.log('Error fetching entries')
  })
  });

  //request to get the orders list filtered
  app.get('/orderSearch', (req, res) => {
    const startDate = new Date (req.query.startDate);
    const endDate = new Date (req.query.endDate);
    const minPrice = parseFloat(req.query.minPrice);
    const maxPrice = parseFloat(req.query.maxPrice);
    startDate.setHours(0, 00, 01);
    endDate.setHours(23, 59, 59);
    var query={};
    if(minPrice==-1 || maxPrice==-1){
       query = {
        orderDate: { $gte: startDate, $lte: endDate }};
    }
    else{
    query = {
    orderDate: { $gte: startDate, $lte: endDate },
    totalAmount: { $gte: minPrice, $lte: maxPrice }};
    }

    try{
      DbShcema[0].find(query).then((orders) => {
        res.status(200).json(orders);
    });
  }
    catch (err) {
      console.error('Failed to fetch orders:', err);
      res.status(500).json({ error: 'Failed to fetch orders' });
  }
  });

  //request to delete an order based on the id
  app.delete('/orders/:id', (req, res) => {
    DbShcema[0].deleteOne({_id: req.params.id})
    .then(() => {
        res.status(200).json({
            message: 'Post Deleted'
        })
    })
  });

  //request to get the product details using th product id
  app.get('/productDetails/:_id', (req, res) => {
    const productId = req.params._id;
    console.log(productId);
    DbShcema[1].findById(productId) 
      .then((products) => {
        res.json(products);

      })
      .catch((error) => {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
      });
  });

//the requests related to the Product Component

//request to get the products list
  app.get('/products', (req, res) => {
    DbShcema[1].find().then((products) => {
        res.json(products);
    })
    .catch(() => {
        console.log('Error fetching entries')
    })

    });
  
    //request to create a new product
  app.post('/productform', (req, res) => {
  
  const { name, price, category } = req.body;

  const newProduct = new DbShcema[1]({
    name,
    price,
    category
  });
    newProduct.save()
      .then(savedProduct => {
        console.log('Product saved:', savedProduct);
        res.status(201).json(savedProduct);
      })
      .catch(error => {
        console.error('Failed to save product:', error);
        res.status(500).json({ error: 'Failed to save product' });
      });
  });
//request to update the product using its ID
  app.put('/productform/:_id', (req, res,next) => {
    const productId = req.params._id;
    const updatedProduct = req.body; 
    DbShcema[1].findByIdAndUpdate(productId, updatedProduct, { new: true })
      .then(() => {
      res.json({ message: 'Product updated successfully' });
    })
    .catch(error => {
      res.status(500).json({ error: 'Failed to update product' });
    });
    next();
  });
  //request to update the total amount of the orders after editing the product
  app.put('/productform/:_id', (req, res) => {

   DbShcema[0].find()
      .populate('productIds')
      .then((orders) => {
        orders.forEach((order) => {
          const totalAmount = order.productIds.reduce((sum, product) => sum + product.price, 0);
          DbShcema[0].findByIdAndUpdate(order._id, { totalAmount })
            .then((updatedOrder) => {
              res.json(updatedOrder);
            })
            .catch((err) => {
              console.error('Failed to update totalAmount:', err);
            });
});
      });
  });
module.exports = app;