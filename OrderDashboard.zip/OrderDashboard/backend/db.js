const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  
    customerName: String,
    productIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
    totalAmount: Number,
    orderDate: { type: Date, default: Date.now },
});

const productSchema = new mongoose.Schema({
  
    name: String,
    price: Number,
    category: String,
});

const Order = mongoose.model('Order', orderSchema);
const Product = mongoose.model('Product', productSchema);
module.exports = [Order,Product]; 


//To create a new order, please uncomment and add the input you want

// const orderData = [{
//     customerName: 'Mariam',
//     orderDate: new Date("2023-08-29T22:55:55.799Z"),
//     productIds: ["64eddcb9aef2637e2164c24c","64eddcb9aef2637e2164c24e"],
//     totalAmount: 100,
//   },];
//   Order.create(orderData)
//     .then((order) => {
//       console.log('Order created:', order);
//       calculateTotalAmount();
//     })
//     .catch((err) => {
//       console.error('Failed to create order:', err);
//     });
// Order.find({})
//   .populate('productIds')
//   .then((order) => {
//       const totalAmount = order.productIds.reduce((sum, product) => sum + product.price, 0);
//       Order.findByIdAndUpdate(order._id, { totalAmount })
//         .then((updatedOrder) => {
//           console.log('Order totalAmount updated:', updatedOrder);
//         })
//         .catch((err) => {
//           console.error('Failed to update totalAmount:', err);
//         });
//   })
//   .catch((err) => {
//     console.error('Failed to populate productIds:', err);
//   });



 