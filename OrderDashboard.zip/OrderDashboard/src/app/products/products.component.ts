import { Component, OnInit } from '@angular/core';
import { ProductInfo } from '../productInfo';
import { OrderDataService } from '../order-data.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit {
  
  productList: any[]=[];
  selectedPrice!: number;
  constructor(private orderData:OrderDataService,private http: HttpClient,private myRouter: Router){}

  ngOnInit(): void {
    this.getProductInfo();
  }

  
//gets the products list from a method in order data service
  getProductInfo(){
   this.orderData.getProductInfo().subscribe(
      (products) => {
        this.productList = products;
      },
      (error) => {
        console.error('Error fetching product details:', error);
      }
    );
}
//routes to create product component and passes the selected product that needs to be edited
editProduct(product:any){

  this.myRouter.navigate(['/createProduct'],{queryParams: {id:product._id,name:product.name,price:product.price,category:product.category}});

}

//routes to create product component
createProduct(){
  this.myRouter.navigate(['/createProduct']);
}
goHome(){
  this.myRouter.navigate(['']);

}

}
