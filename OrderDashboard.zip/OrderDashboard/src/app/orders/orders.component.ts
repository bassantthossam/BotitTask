import { Component, OnInit } from '@angular/core';
import { OrderDataService } from '../order-data.service';
import { OrderInfo } from '../orderInfo';
import { HttpClient } from '@angular/common/http';
import { formatDate } from '@angular/common';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';



@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit{
  orderList: any[]=[];
  startDate: Date=new Date("1970-08-29T12:12:01.429Z");
  endDate: Date= new Date("3000-08-29T12:12:01.429Z");
  minPrice: number=0;
  maxPrice: number=100000;
  selectedProduct:any;

  
  constructor(private orderData:OrderDataService,private http: HttpClient,private formBuilder: FormBuilder,private myRouter: Router){

  }

  ngOnInit(){
    this.getOrderInfo();
    
    
  }
//gets the orders list
  getOrderInfo(){
    this.http.get<any[]>('http://localhost:3000/orders').subscribe((orderList) => {  
    this.orderList = orderList;});
}

//show the cancel button if the order date was before less than 3 days
shouldShowDeleteButton(orderDate: Date): boolean {
  const format = 'dd/MM/yyyy';
   const currentDate = new Date();
  const threeDaysAgo = new Date();
  const locale = 'en-US';
  threeDaysAgo.setDate(currentDate.getDate() - 3);
  const orderD = formatDate(orderDate, format, locale);
  const threeDays = formatDate(threeDaysAgo, format, locale);


  return (orderD >= threeDays) ;
}

//Deletes the selected order
onDelete(id:number){
    this.http.delete('http://localhost:3000/orders/'+id).subscribe(() => {
        this.getOrderInfo();
      });
  }

  //calls another method in the service component that searches for the order based on the user input
  searchOrders() {
    this.orderData.searchOrders(this.startDate, this.endDate, this.minPrice, this.maxPrice)
      .subscribe((orders) => {
        this.orderList = orders;
      });
  }

  //gets the product details using the product ID
  getProductDetails(id: number) {
    this.http.get<any[]>('http://localhost:3000/productDetails/'+id)
      .subscribe(
        (data) => {
          this.selectedProduct = data;
        },
        (error) => {
          console.error(error);
        }
      );
     console.log(this.selectedProduct);
  }
 
  goHome(){
    this.myRouter.navigate(['']);

  }
}
